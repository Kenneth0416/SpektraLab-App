# Silvercam (銀鹽工坊 / 银盐工坊) — Licensing, Attribution & Modification Notices

**Display Brand:** Silvercam (Traditional Chinese: 銀鹽工坊; Simplified Chinese: 银盐工坊)  
*Notice regarding brand name:* "Silvercam" / "銀鹽工坊" / "银盐工坊" are display names adopted for this project to clearly distinguish it from upstream projects. This name is not trademark-cleared; no trademark clearance is claimed or implied.  
**Canonical Source Repository:** https://github.com/Kenneth0416/SpektraLab-App  
**Version:** 0.1.0  
**Date:** 2026-11-11  

---

## 1. Independent Downstream Project & Non-Endorsement Notice

Silvercam is an independent downstream port, interaction design prototype, and software application. It is **NOT** affiliated with, sponsored by, or endorsed by Andrea Volpato, the upstream [spektrafilm](https://github.com/andreavolpato/spektrafilm) project, or James Qiu ([SpektraLab](https://github.com/JamesQiu2005/SpektraLab)).

References to photographic film, motion-picture stock, or photo-paper names (such as Kodak, Portra, Ektar, Gold, UltraMax, Vision3, Double-X, Verita, Kodachrome, Ektachrome, Endura, Fujifilm, Velvia, Provia, Crystal Archive) describe historical emulsions and profile data ported from the upstream spektrafilm scientific models. All trademarks and trade names remain the property of their respective owners. No affiliation, sponsorship, or commercial endorsement is claimed or implied.

---

## 2. Dual Licensing Structure

Silvercam distinguishes between executable software code and spectral/profile data assets:

### (A) Application, Engine & Web Source Code — GNU GPL v3.0

- **Scope:** All Android application code (`app/`), Kotlin spectral film simulation runtime and DNG linear RAW developer (`engine/`), GLSL ES 3.00 shaders, web darkroom application and presentation website (`src/`, `public/`, `index.html`), build scripts (`scripts/`), and tools (`tools/`).
- **Upstream Origin:** Derived and ported from [spektrafilm](https://github.com/andreavolpato/spektrafilm) (and desktop GUI components by Andrea Volpato: `white_padding`, `gray_18_canvas`, virtual photo paper watermark concepts, and polaroid development animation) at commit `3bb2c2d2801ff68b92019cf1dbcbb133d60832bc` (v0.3.4), with interaction references from [SpektraLab](https://github.com/JamesQiu2005/SpektraLab).
- **License:** GNU General Public License, Version 3 (GPLv3).
- **License Text:** See the root [`LICENSE`](./LICENSE) file or https://www.gnu.org/licenses/gpl-3.0.html.
- **NO WARRANTY (GPLv3 Sections 15–16):**  
  *This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.*

### (B) Film Profiles, Paper Profiles & Optical Data — CC BY-SA 4.0

- **Scope:** Binary optical and spectral data files under `app/src/main/assets/spektra/` (`film/*.spk`, `paper/*.spk`, `global.spk`, `index.json`), generated from spektrafilm profile databases.
- **Author & Canonical Origin:** Andrea Volpato — https://github.com/andreavolpato/spektrafilm
- **License:** Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).
- **Author Preamble v1.1:** Upstream author Andrea Volpato provided an accompanying preamble dated 2026-05-28, preserved verbatim in [`app/src/main/assets/spektra/SPEKTRAFILM_LICENSE.txt`](./app/src/main/assets/spektra/SPEKTRAFILM_LICENSE.txt).
- **Non-Binding Nature of Preamble Requests:** As explicitly stated by the upstream author in the preamble ("These are not legal requirements. They are the spirit of the project, stated plainly..."), requests regarding commercial AI training and standalone LUT reselling are polite requests rather than binding legal terms of the CC BY-SA 4.0 public license. Furthermore, lack of per-binary embedded credit (e.g. inside compact binary SPK tables) is not necessarily a copyright violation; attribution is provided fully across documentation, UI, and release archives.

### (C) User Outputs (Photographs & Videos) — No Copyleft

Per Section 2 of the upstream spektrafilm CC BY-SA 4.0 preamble and GNU GPLv3 principles:
- **Finished photographs and videos produced, graded, or exported using Silvercam / spektrafilm do NOT acquire copyleft.**
- The creative works you create are entirely yours.
- Free use forever, on any personal, educational, or commercial production. No royalties, no output licensing obligations, and no mandatory watermark on your exported images or videos.

---

## 3. GPL Corresponding Source Notice (GPLv3 Section 6)

- **Source Code Repository:** https://github.com/Kenneth0416/SpektraLab-App
- **Downloadable Release Source:** Shipped releases provide corresponding source ZIP archives (e.g. `Silvercam-App-source.zip`) containing the exact files, build configurations, and tools used to create the binaries.
- **Notice on Generic Repository URLs:** In compliance with GPLv3 Section 6, please note that a link to a generic repository homepage or moving default branch (`main`) does not guarantee a matching 1:1 state with any specific pre-built binary. Users and distributors should refer to the exact commit tags or release source archives matching that build.

---

## 4. Modification History & Dated Notices (GPLv3 Section 5(a))

- **2026-11-10:**
  - Ported upstream spektrafilm v0.3.4 (Python / NumPy / colour-science pipeline) to pure Kotlin/JVM (`engine/`) and GLSL ES 3.00 shaders.
  - Baked JSON profiles into compact SPK1 binary format (`tools/bake/bake_spektrafilm.py`).
  - Created Android native Jetpack Compose application (`app/`).
- **2026-11-11:**
  - Added linear DNG RAW developer, CameraX film viewfinder, and foldable posture adaptation.
  - Ported desktop GUI styles (paper border, 18% gray canvas, development animation).
  - Adopted display brand **Silvercam (銀鹽工坊 / 银盐工坊)** (not trademark-cleared) to distinguish from upstream spektrafilm and SpektraLab.
  - Replaced paper-back watermark graphic with independent neutral geometric artwork (`paper_back_mark.png`).
  - Launched trilingual web application and interactive darkroom landing page (Traditional Chinese, Simplified Chinese, English) with downloadable release packages.
  - Added comprehensive in-app and web credits, licensing documentation, and corresponding source packaging.

---

## 5. Third-Party Fonts & Component Licenses

- **LXGW WenKai Regular v1.530 (current native Android app):** Copyright 2021–2026 LXGW; Copyright 2020 The Klee Project Authors. The complete, unmodified official font is bundled under SIL Open Font License, Version 1.1. See [the complete license](./app/src/main/assets/licenses/OFL-LXGWWenKai.txt) and [source, checksum and coverage documentation](./app/tools/FONTS.md).
- **Silvercam Hand Web (current website):** An independently renamed and modified WOFF2 subset of LXGW WenKai Regular v1.530, retaining the upstream copyright and SIL OFL 1.1. It is not endorsed by the upstream authors. See [the complete license](./public/fonts/OFL-WenKai.txt), [modification notice](./public/fonts/README.txt), and [source/artifact manifest](./public/fonts/manifest.json).
- **Martian Mono (Evil Martians):** Bundled under SIL Open Font License, Version 1.1. The website self-hosts unmodified v1.1.0 Regular/Medium/Bold WOFF2 files; the native app retains its existing font. Copyright notices and full terms are preserved in the respective [website](./public/fonts/OFL-MartianMono.txt) and native application license assets.
- **System Chinese fonts:** Current body text uses platform fonts and locale-aware fallback; no Noto body font is bundled by this change. Installed system fonts retain their own licenses. Naming a font in a CSS fallback list does not distribute that font.
- **Historical Long Cang attribution:** Copyright 2018 The LongCang Project Authors, SIL OFL 1.1. Earlier releases and historical prototype notices may refer to Long Cang; it has been replaced in the current native app and website. Historical artifacts and their notices are not rewritten by this change.

The bundled fonts retain their SIL OFL 1.1 licenses rather than becoming GPL-covered font assets. OFL permits commercial use, embedding and redistribution subject to its conditions, including preserving copyright and license notices, not selling the fonts by themselves, and respecting Reserved Font Names for modified versions. The website subset uses a new name; the native WenKai font remains byte-identical to the official release. Font use does not impose OFL on application code or generated photographs.
- **Lucide Icons:** Copyright (c) Lucide Contributors. Licensed under ISC License.
- **React, React Router, Vite, fflate:** Licensed under MIT License.


LibRaw-derived RAW decoding and camera matrices (2026-11-12)

CameraMatrices.kt contains 808 camera coefficient rows, maker normalization and
model aliases generated by tools/gen_camera_matrices.py from LibRaw 0.22.2,
release tag 0.22.2, commit b93f6e45c194f5df9b02a43b1af9a54b4f41f33f:
https://github.com/LibRaw/LibRaw/tree/b93f6e45c194f5df9b02a43b1af9a54b4f41f33f
Inputs: src/tables/colordata.cpp, src/metadata/identify.cpp,
src/metadata/normalize_model.cpp and libraw/libraw_version.h. Regeneration from
these pinned files was byte-identical to the imported Kotlin table. Exact input
SHA-256 hashes are recorded in tools/libraw-provenance.json.

Copyright 2008-2025 LibRaw LLC; the three source files carry Copyright 2019-2025
LibRaw LLC. LibRaw uses unrestricted code from dcraw.c, Copyright 1997-2018
Dave Coffin. The coefficient source states that matrices are from Adobe DNG
Converter unless otherwise noted. Lossless JPEG category-16 handling and DNG
sample reassembly also follow dcraw/LibRaw, as identified in their source headers.

LibRaw offers LGPL 2.1 or CDDL 1.0. This downstream selects the LGPL 2.1 route
and exercises LGPL 2.1 section 3 to distribute its modified/translated derived
code under GPL version 3, whose full text is supplied with this application.
It does not select CDDL. The upstream LGPL 2.1 text is retained as
LIBRAW_LGPL_2_1.txt. No upstream binary library is linked by this implementation.
LibRaw LLC and Dave Coffin do not endorse this application.

Downstream changes dated 2026-11-12: Kotlin table generation and lookup;
TIFF/EXIF and packed/lossless-JPEG DNG support; bounded directory/segment/sample
validation; integration with linear burst DNG, dual calibration and camera
metadata; exposure-invariant neutral normalization. The lookup table is
infrastructure: production DNG color conversion uses the file's own matrices.
