package app.spektralab.ui

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.spektralab.R
import app.spektralab.camera.CameraFormat
import app.spektralab.camera.RawShooter
import app.spektralab.camera.FilmViewfinder
import app.spektralab.engine.Catalog
import app.spektralab.engine.LookMapper
import app.spektralab.render.Framing
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val CAMERA_LOG_TAG = "SilvercamCamera"

@androidx.annotation.OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
private fun logRawCameraCapabilities(cameraInfo: androidx.camera.core.CameraInfo) {
    runCatching {
        val info = androidx.camera.camera2.interop.Camera2CameraInfo.from(cameraInfo)
        val capabilities = info.getCameraCharacteristic(
            android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
        val rawSizes = info.getCameraCharacteristic(
            android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?.getOutputSizes(android.graphics.ImageFormat.RAW_SENSOR)
        Log.i(CAMERA_LOG_TAG, "Camera2 id=${info.cameraId} capabilities=${capabilities?.contentToString()} " +
            "rawAdvertised=${capabilities?.contains(android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)} " +
            "rawSensorSizes=${rawSizes?.contentToString()}")
    }.onFailure { Log.w(CAMERA_LOG_TAG, "Camera2 RAW diagnostics unavailable", it) }
}

private class CameraSession(val camera: Camera, val capture: ImageCapture, val raw: Boolean,
                            /** For raw capture into memory; null when the camera would not tell. */
                            val chars: android.hardware.camera2.CameraCharacteristics? = null)

/**
 * The camera: a live viewfinder through the loaded film, and a shutter that saves the
 * untouched original (the sensor's raw data as DNG when the device offers it) to the
 * album. The shot goes on the lightbox with the camera's look, which stays editable.
 */
@Composable
fun CameraScreen(state: AppState) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val look by state.camLook.collectAsState()
    val activeSheet by state.sheet.collectAsState()
    val accent by animateColorAsState(Color(Catalog.film(look.film).accent), tween(500), label = "accent")
    var tool by rememberSaveable { mutableStateOf("film") }
    var front by rememberSaveable { mutableStateOf(false) }
    var flash by rememberSaveable { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var session by remember { mutableStateOf<CameraSession?>(null) }
    var selectedCameraId by remember { mutableStateOf<String?>(null) }
    var separateLenses by remember { mutableStateOf<List<SeparateLens>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    // what the shutter keeps as the original: JPEG (film effect on the preview), single RAW, or a RAW burst
    val format by state.cameraFormat.collectAsState()
    val multiFrame = format == CameraFormat.RAW_BURST
    // whether the bound camera's hardware can take RAW at all (queried per lens)
    var rawSupported by remember { mutableStateOf(false) }
    val merging by state.merging.collectAsState()
    // frames the next shot will take: follows the light (sensor gain) while multi-frame is on
    var burstFrames by remember { mutableIntStateOf(RawShooter.MAX_FRAMES) }
    LaunchedEffect(session, multiFrame) {
        val chars = session?.chars ?: return@LaunchedEffect
        while (multiFrame) { burstFrames = state.shooter.frameCount(chars); kotlinx.coroutines.delay(400) }
    }
    // exposure compensation for the film exposure, set by dragging on the finder after a tap
    var evBias by rememberSaveable { mutableFloatStateOf(0f) }
    // focus / metering point: 0 searching, 1 in focus, 2 could not focus; locked = held until tapped again
    var focusResult by remember { mutableIntStateOf(0) }
    var focusLocked by remember { mutableStateOf(false) }
    var focusTouchedAt by remember { mutableLongStateOf(0L) }

    // permission
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) ask.launch(Manifest.permission.CAMERA) }

    // viewfinder pipeline
    val viewfinder = remember { FilmViewfinder(context) { msg -> ContextCompat.getMainExecutor(context).execute { state.say(msg) } } }
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            // TextureView lets the shutter wait for a blurred buffer to be latched.
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val lookState = rememberUpdatedState(look)
    val filmPreview = session?.raw != true
    LaunchedEffect(filmPreview) {
        if (!filmPreview) return@LaunchedEffect
        snapshotFlow { lookState.value }.distinctUntilChanged().collectLatest { l ->
            // Building a LookSetup runs the print stage. Skip it while RAW has detached the effect.
            val setup = withContext(Dispatchers.Default) { runCatching { state.app.looks.get(l) }.getOrNull() }
            if (setup != null && filmPreview) viewfinder.setLook(setup)
        }
    }

    // bind the camera while this screen is shown; a format change re-binds, because the
    // use case group (JPEG or RAW capture) and the preview effect change with it
    DisposableEffect(granted, front, selectedCameraId, format) {
        var provider: ProcessCameraProvider? = null
        var disposed = false
        if (granted) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                if (disposed) return@addListener
                val p = runCatching { future.get() }.getOrNull() ?: return@addListener
                provider = p
                var selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (!runCatching { p.hasCamera(selector) }.getOrDefault(false)) {
                    selector = if (front) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                    if (!runCatching { p.hasCamera(selector) }.getOrDefault(false)) { state.say(R.string.no_camera); return@addListener }
                }
                separateLenses = discoverSeparateLenses(p, selector)
                selectedCameraId?.let { id ->
                    separateLenses.firstOrNull { it.id == id }?.let { selector = it.selector }
                }
                val fourThree = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY).build()
                rawSupported = runCatching {
                    val info = p.getCameraInfo(selector)
                    logRawCameraCapabilities(info)
                    val formats = ImageCapture.getImageCaptureCapabilities(info).supportedOutputFormats
                    val supported = formats.contains(ImageCapture.OUTPUT_FORMAT_RAW)
                    Log.i(CAMERA_LOG_TAG, "CameraX outputFormats=$formats rawSupported=$supported")
                    supported
                }.onFailure {
                    Log.e(CAMERA_LOG_TAG, "RAW capability query failed; defaulting to JPEG", it)
                }.getOrDefault(false)

                fun bind(raw: Boolean): CameraSession {
                    Log.i(CAMERA_LOG_TAG, "Binding preview + image capture: raw=$raw filmEffect=${!raw}")
                    val preview = Preview.Builder().setResolutionSelector(fourThree).build()
                        .also { it.surfaceProvider = previewView.surfaceProvider }
                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .apply {
                            // raw: the sensor's own data (Camera2 RAW_SENSOR), written as DNG
                            if (raw) setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW)
                            else { setOutputFormat(ImageCapture.OUTPUT_FORMAT_JPEG); setResolutionSelector(fourThree) }
                            if (raw) requestRawMetadata(this, state.shooter.results)
                        }.build()
                    // CameraX rejects RAW together with any CameraEffect, including a preview-only one.
                    // The saved photo still receives its film look. Exposure feedback is a direct overlay.
                    val group = UseCaseGroup.Builder().addUseCase(preview).addUseCase(capture)
                        .apply { if (!raw) addEffect(viewfinder.effect) }.build()
                    p.unbindAll()
                    val camera = p.bindToLifecycle(owner, selector, group)
                    return CameraSession(camera, capture, raw, if (raw) cameraCharacteristics(context, camera) else null).also {
                        Log.i(CAMERA_LOG_TAG, "Camera bound: raw=$raw rawCharacteristicsAvailable=${it.chars != null}")
                    }
                }
                session = runCatching { bind(format != CameraFormat.JPEG && rawSupported) }.recoverCatching {
                    // some devices list raw but cannot stream it next to the preview
                    if (format != CameraFormat.JPEG && rawSupported) {
                        Log.e(CAMERA_LOG_TAG, "RAW binding failed; retrying JPEG", it)
                        bind(false)
                    } else throw it
                }.onFailure {
                    Log.e(CAMERA_LOG_TAG, "Camera binding failed", it)
                    state.say(R.string.camera_open_failed, it.message ?: context.getString(R.string.unknown_error))
                    // Recover the default lens when an auxiliary camera cannot host our use cases.
                    if (selectedCameraId != null) selectedCameraId = null
                }.getOrNull()
                session?.camera?.let { camera ->
                    val range = camera.cameraInfo.zoomState.value
                    zoom = range?.let { zoom.coerceIn(it.minZoomRatio, it.maxZoomRatio) } ?: 1f
                    camera.cameraControl.setZoomRatio(zoom)
                }
            }, ContextCompat.getMainExecutor(context))
        }
        onDispose {
            disposed = true
            session = null
            runCatching { provider?.unbindAll() }
        }
    }
    DisposableEffect(Unit) { onDispose { viewfinder.release() } }
    LaunchedEffect(evBias) { viewfinder.evBias = evBias }
    // The gesture is film exposure, applied once as autoEv + evBias on the saved frame.
    // RAW must not also set camera exposure compensation, or the sensor and the film each add it.
    LaunchedEffect(front) { focusLocked = false }
    // zoom range of the bound lens (0.5x ultra-wide, tele steps)
    var zoomRange by remember { mutableStateOf(1f to 1f) }
    DisposableEffect(session) {
        val live = session?.camera?.cameraInfo?.zoomState
        val obs = androidx.lifecycle.Observer<androidx.camera.core.ZoomState> { zoomRange = it.minZoomRatio to it.maxZoomRatio }
        live?.observe(owner, obs)
        onDispose { live?.removeObserver(obs) }
    }
    // read the lens data once per bound session, not per recomposition
    val lens = remember(session) { session?.let { readLens(context, it.camera) } }
    // zoom stops shared by the chips and the pinch haptic; real lenses when they can be read
    val zoomStops = remember(zoomRange, lens) {
        val (min, max) = zoomRange
        val real = lens?.stops.orEmpty()
        app.spektralab.camera.lensZoomStops(min, max, real)
    }
    // 35mm-equivalent label for a zoom ratio; null when the focal length is unknown (falls back to ×)
    val baseMm = lens?.baseMm
    // A camera exposed as a separate CameraX device cannot be reached with setZoomRatio.
    val lensChoices = remember(lens, separateLenses, zoomStops, zoomRange) {
        val alternatives = if (lens == null) emptyList() else app.spektralab.camera.separateLensRatios(
            lens.id, lens.baseMm, lens.stops, zoomRange.first, zoomRange.second,
            separateLenses.map { it.id to it.baseMm },
        ).map { (id, ratio) -> ratio to separateLenses.first { it.id == id } }
        (zoomStops.filter { z -> alternatives.none { app.spektralab.camera.nearLensRatio(it.first, z) } }
            .map { it to null } + alternatives).sortedBy { it.first }
    }
    // only talk to the camera when the ratio really changed (pinch events often repeat a value)
    var appliedZoom by remember(session) { mutableFloatStateOf(Float.NaN) }
    fun applyZoom(z: Float) {
        zoom = z
        if (z == appliedZoom) return
        appliedZoom = z
        session?.camera?.cameraControl?.setZoomRatio(z)
    }
    var zoomJob by remember { mutableStateOf<Job?>(null) }
    // chips and double tap glide to the target; a pinch or lens flip cancels the glide
    fun animateZoom(target: Float) {
        zoomJob?.cancel()
        zoomJob = scope.launch {
            Animatable(zoom).animateTo(target.coerceIn(zoomRange.first, zoomRange.second), Motion.glide) {
                // a spring may overshoot the lens range, which the camera rejects
                applyZoom(value.coerceIn(zoomRange.first, zoomRange.second))
            }
        }
    }


    // ------------------------------------------------------------------ film transport
    // Like a mechanical camera: releasing the shutter leaves the frame exposed and the
    // finder goes to ground glass until the film is advanced with the lever.
    val prefs = remember { context.getSharedPreferences("camera", android.content.Context.MODE_PRIVATE) }
    var cocked by remember { mutableStateOf(prefs.getBoolean("cocked", true)) }
    var frame by remember { mutableIntStateOf(prefs.getInt("frame", 1)) }
    var autoWind by remember { mutableStateOf(prefs.getBoolean("autoWind", false)) }
    var nudge by remember { mutableIntStateOf(0) }
    var autoStroke by remember { mutableIntStateOf(0) }
    val blades = remember { Animatable(0f) }
    val clarity = remember { Animatable(if (prefs.getBoolean("cocked", true)) 1f else 0f) }
    LaunchedEffect(Unit) { snapshotFlow { clarity.value }.collect { viewfinder.clarity = it } }
    fun advanceFilm() {
        if (busy || cocked) return
        busy = true
        cocked = true
        frame = frame % 36 + 1
        prefs.edit().putBoolean("cocked", true).putInt("frame", frame).apply()
        // the finder snaps back into focus
        scope.launch {
            clarity.animateTo(1f, tween(520, easing = LinearOutSlowInEasing))
            // Also recover a curtain held closed because the preview stalled.
            blades.animateTo(0f, tween(260, easing = LinearOutSlowInEasing))
            busy = false
        }
    }

    // ------------------------------------------------------------------ orientation
    // The picture is tagged with the way the phone is actually held, also when screen
    // rotation is locked; controls then turn in place like on other phone cameras.
    var deviceDeg by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val l = object : android.view.OrientationEventListener(context) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                val snapped = when (o) { in 45 until 135 -> 90; in 135 until 225 -> 180; in 225 until 315 -> 270; else -> 0 }
                if (snapped != deviceDeg) deviceDeg = snapped
            }
        }
        if (l.canDetectOrientation()) l.enable()
        onDispose { l.disable() }
    }
    val displayDeg = when (androidx.compose.ui.platform.LocalView.current.display?.rotation) {
        android.view.Surface.ROTATION_90 -> 90; android.view.Surface.ROTATION_180 -> 180; android.view.Surface.ROTATION_270 -> 270; else -> 0
    }
    val turn = (((-(deviceDeg + displayDeg)) % 360 + 540) % 360 - 180).let { if (it == -180) 180 else it }
    val iconTurn by animateFloatAsState(turn.toFloat(), Motion.settle, label = "turn")

    // focal-plane shutter: two blades close over the frame and open again
    fun shoot() {
        val s = session ?: return state.say(if (granted) R.string.camera_not_ready else R.string.camera_permission_required)
        if (busy) return
        // RAW frames are held in memory until they are merged; JPEG hands the file to CameraX
        // in the background and never blocks the next shot.
        if (s.raw && !state.shooter.available) return state.say(R.string.previous_shot_processing)
        if (!cocked) {
            // shutter is locked until the film is advanced
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            nudge++
            return
        }
        busy = true
        cocked = false
        prefs.edit().putBoolean("cocked", false).apply()
        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        val captured = CompletableDeferred<Boolean>()
        val shutter = scope.launch {
            blades.animateTo(1f, tween(70, easing = FastOutLinearInEasing))
            val previousBlur = viewfinder.blurredTimestamp
            clarity.snapTo(0f)
            viewfinder.clarity = 0f
            // RAW has no processed preview buffers. The Compose dim still marks a spent frame,
            // so the curtain reopens without waiting for a GL blur that will never arrive.
            if (s.raw || previewView.awaitBlurredPreview(viewfinder, previousBlur)) {
                blades.animateTo(0f, tween(260, easing = LinearOutSlowInEasing))
            } else {
                state.say(R.string.viewfinder_stalled)
            }
        }
        scope.launch {
            if (captured.await()) {
                shutter.join()
                busy = false
                if (autoWind) autoStroke++
            } else {
                // Cancel before restoring clarity so the old shot cannot blur it again.
                shutter.cancelAndJoin()
                cocked = true
                prefs.edit().putBoolean("cocked", true).apply()
                clarity.animateTo(1f, tween(300))
                blades.animateTo(0f, tween(260, easing = LinearOutSlowInEasing))
                busy = false
            }
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        s.capture.targetRotation = when (deviceDeg) {
            90 -> android.view.Surface.ROTATION_270; 180 -> android.view.Surface.ROTATION_180
            270 -> android.view.Surface.ROTATION_90; else -> android.view.Surface.ROTATION_0
        }
        // the original through CameraX's own saving: JPEG, or raw where frames cannot be taken into memory
        fun saveThroughCameraX() {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "SPK_$stamp." + if (s.raw) "dng" else "jpg")
                put(MediaStore.Images.Media.MIME_TYPE, if (s.raw) "image/x-adobe-dng" else "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/Silvercam")
            }
            s.capture.flashMode = flash
            val options = ImageCapture.OutputFileOptions.Builder(context.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
            val initiated = runCatching {
                s.capture.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                        if (s.raw) captured.complete(true)
                        result.savedUri?.let { state.onCaptured(it, evBias) } ?: state.say(R.string.original_not_saved)
                    }

                    override fun onError(e: ImageCaptureException) {
                        // JPEG already released the transport when the request was accepted; a
                        // late failure is reported, but the advanced frame is not rewound.
                        if (!captured.isCompleted) captured.complete(false)
                        state.say(R.string.capture_failed, e.message ?: e.imageCaptureError.toString())
                    }
                })
            }
            // JPEG: the request is in CameraX's hands. The film transport only waits for the
            // shutter curtain, so consecutive shots are not blocked by background saves.
            if (initiated.isSuccess && !s.raw) captured.complete(true)
            if (initiated.isFailure) {
                captured.complete(false)
                state.say(R.string.capture_failed, initiated.exceptionOrNull()?.message ?: context.getString(R.string.unknown_error))
            }
        }
        val chars = s.chars
        if (s.raw && chars != null && !state.shooter.unsupported) {
            // raw frames into memory: one, or a burst that is merged in the background
            val frames = if (multiFrame) state.shooter.frameCount(chars) else 1
            s.capture.flashMode = if (frames > 1) ImageCapture.FLASH_MODE_OFF else flash
            if (frames > 1) state.say(R.string.burst_hold_steady, frames)
            val accepted = state.shooter.shoot(s.capture, chars, frames, "SPK_$stamp", evBias) { ok, retry ->
                when {
                    ok -> captured.complete(true)
                    retry && session === s -> saveThroughCameraX()
                    else -> { captured.complete(false); state.say(R.string.capture_failed_short) }
                }
            }
            if (!accepted) { captured.complete(false); state.say(R.string.previous_shot_processing) }
        } else saveThroughCameraX()
    }
    val shootNow by rememberUpdatedState(::shoot)
    LaunchedEffect(Unit) { state.shutterKey.collect { shootNow() } }

    val config = LocalConfiguration.current
    val landscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
    // The picture is landscape when the phone is held a quarter turn from the fixed screen.
    val pictureLandscape = landscape != (turn == 90 || turn == -90)
    // Like other phone cameras: the screen stays put and the controls turn in place.
    // Phones lock upright; foldables and large screens keep rotating so half-fold postures
    // (tabletop / book) can be detected instead of being frozen in portrait.
    val activity = remember(context) {
        generateSequence(context) { (it as? android.content.ContextWrapper)?.baseContext }.filterIsInstance<Activity>().firstOrNull()
    }
    val fold = LocalFold.current
    DisposableEffect(activity, config.smallestScreenWidthDp, config.screenWidthDp, fold.posture) {
        // A locked orientation has no effect in split screen, and unlocking there can fight the system.
        val lock = activity != null && !activity.isInMultiWindowMode
        val unfolded = config.screenWidthDp >= 600 || fold.posture != Posture.NORMAL
        if (lock) activity.requestedOrientation = when {
            unfolded -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            config.smallestScreenWidthDp < 600 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
        }
        onDispose { if (lock) activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val hinge = fold.hinge?.translate(-origin)
    val density = androidx.compose.ui.platform.LocalDensity.current
    var toolsOpen by rememberSaveable { mutableStateOf(false) }
    val items by state.library.items.collectAsState()
    val last = items.firstOrNull()
    val positive = state.app.engine.film(LookMapper.filmStock(look)).isPositive

    // ------------------------------------------------------------------ parts
    val topItems: @Composable (@Composable () -> Unit) -> Unit = { gap ->
        Text(stringResource(R.string.back_to_lightbox), color = Pal.text, fontSize = 15.sp, modifier = Modifier.springClick { state.closeCamera() }.graphicsLayer { rotationZ = iconTurn }.padding(6.dp))
        // what the shutter will keep as the original
        AnimatedContent(session?.raw, label = "format", transitionSpec = { fadeIn() togetherWith fadeOut() }) { raw ->
            // tapping the badge cycles JPEG → RAW → RAW burst; without RAW hardware it stays on JPEG
            Text(when (raw) { true -> if (multiFrame) "RAW×$burstFrames" else "RAW"; false -> "JPEG"; null -> "…" },
                fontFamily = Fonts.mono, fontSize = 10.sp,
                color = if (raw == true) accent else Pal.dim,
                modifier = Modifier.springClick {
                    val next = CameraFormat.cycle(format, rawSupported)
                    if (next == format) return@springClick
                    state.setCameraFormat(next)
                    state.say(when (next) {
                        CameraFormat.JPEG -> R.string.camera_format_jpeg
                        CameraFormat.RAW_SINGLE -> R.string.camera_format_raw
                        CameraFormat.RAW_BURST -> R.string.camera_format_raw_burst
                    })
                }.graphicsLayer { rotationZ = iconTurn }.padding(6.dp).border(1.dp, if (raw == true) accent else Pal.off, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
        }
        merging?.let { Text(stringResource(R.string.merging_percent, (it * 100).toInt()), fontFamily = Fonts.mono, fontSize = 10.sp, color = Pal.dim,
            modifier = Modifier.graphicsLayer { rotationZ = iconTurn }.padding(2.dp)) }
        gap()
        val flashLabel = stringResource(when (flash) {
            ImageCapture.FLASH_MODE_ON -> R.string.flash_on
            ImageCapture.FLASH_MODE_AUTO -> R.string.flash_auto
            else -> R.string.flash_off
        })
        Text(flashLabel, color = if (flash == ImageCapture.FLASH_MODE_OFF) Pal.dim else Pal.text, fontSize = 13.sp, modifier = Modifier.springClick {
            flash = when (flash) {
                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }.graphicsLayer { rotationZ = iconTurn }.padding(8.dp))
        Text(stringResource(R.string.recipes), color = Pal.text, fontSize = 13.sp, modifier = Modifier.springClick { state.openRecipes() }.graphicsLayer { rotationZ = iconTurn }.padding(8.dp))
        // the film settings stay out of the way until asked for
        val toolsInk by animateColorAsState(if (toolsOpen) Pal.dink else Pal.text, tween(180), label = "toolsInk")
        val toolsBg by animateColorAsState(if (toolsOpen) accent else Color.Transparent, tween(180), label = "toolsBg")
        Text(stringResource(R.string.adjust), color = toolsInk, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 2.dp)
            .springClick { toolsOpen = !toolsOpen }.graphicsLayer { rotationZ = iconTurn }.clip(RoundedCornerShape(14.dp)).background(toolsBg)
            .border(1.dp, accent, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 5.dp))
    }

    val viewfinderPart: @Composable (Modifier, Boolean) -> Unit = { modifier, waistLevel ->
        val finderPad = if (waistLevel) Modifier.padding(18.dp) else Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        Box(modifier.then(finderPad), contentAlignment = Alignment.Center) {
            val aspect = if (waistLevel) {
                // Ground glass is square for 6×6, otherwise the format's own aspect, kept portrait-friendly.
                val fmt = Catalog.format(look.format).aspect.toFloat()
                if (kotlin.math.abs(fmt - 1f) < 0.04f) 1f else fmt.coerceIn(0.7f, 1.4f)
            } else if (landscape) 4f / 3f else 3f / 4f
            BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                val boxAspect = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 1f
                var focusAt by remember { mutableStateOf<Offset?>(null) }
                val focusRing = remember { Animatable(0f) }
                Box(Modifier.aspectRatio(aspect, matchHeightConstraintsFirst = aspect < boxAspect)
                    .then(if (waistLevel) Modifier
                        .border(3.dp, Color(0xFF8A7348), RoundedCornerShape(2.dp))
                        .padding(3.dp)
                        .border(1.dp, Color(0xFFC4A574).copy(alpha = 0.7f), RoundedCornerShape(1.dp))
                        .background(Color(0xFF1A140C))
                    else Modifier)
                    .pointerInput(session) {
                        // tap: focus and meter the sensor there (released after a few seconds);
                        // long press: hold focus until the next tap (AE continues to meter)
                        fun focusOn(p: Offset, lock: Boolean) {
                            val s = session ?: return
                            val point = previewView.meteringPointFactory.createPoint(p.x, p.y)
                            val action = FocusMeteringAction.Builder(point).apply {
                                if (lock) disableAutoCancel() else setAutoCancelDuration(4, java.util.concurrent.TimeUnit.SECONDS)
                            }.build()
                            focusAt = p
                            focusResult = 0
                            focusLocked = lock
                            focusTouchedAt = System.currentTimeMillis()
                            scope.launch { focusRing.snapTo(1f); focusRing.animateTo(if (lock) 0.6f else 0f, tween(if (lock) 300 else 1600)) }
                            runCatching {
                                val f = s.camera.cameraControl.startFocusAndMetering(action)
                                f.addListener({
                                    // the lens reports whether it actually found focus
                                    focusResult = if (runCatching { f.get().isFocusSuccessful }.getOrDefault(false)) 1 else 2
                                    if (focusResult == 1) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }, ContextCompat.getMainExecutor(context))
                            }
                        }
                        detectTapGestures(
                            onTap = { p ->
                                if (focusLocked) {
                                    // unlock: back to continuous autofocus and metering
                                    focusLocked = false
                                    runCatching { session?.camera?.cameraControl?.cancelFocusAndMetering() }
                                    scope.launch { focusRing.animateTo(0f, tween(250)) }
                                } else focusOn(p, lock = false)
                            },
                            onLongPress = { p -> haptics.performHapticFeedback(HapticFeedbackType.LongPress); focusOn(p, lock = true) },
                            onDoubleTap = { evBias = 0f },
                        )
                    }
                    .pointerInput(session, zoomRange, zoomStops) {
                        // pinch to zoom: follows the fingers directly, no animation
                        detectTransformGestures { _, pan, change, _ ->
                            if (change != 1f) {
                                zoomJob?.cancel()
                                val old = zoom
                                val new = (old * change).coerceIn(zoomRange.first, zoomRange.second)
                                // tick when crossing (or landing on) a stop
                                if (new != old && zoomStops.any { (old - it) * (new - it) < 0f || (new == it && old != it) })
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                applyZoom(new)
                            } else if (focusLocked || System.currentTimeMillis() - focusTouchedAt < 5000) {
                                focusTouchedAt = System.currentTimeMillis()
                                evBias = (evBias - pan.y / 240.dp.toPx() * 2f).coerceIn(-2f, 2f)
                            }
                        }
                    }) {
                    if (granted) AndroidView({ previewView }, Modifier.fillMaxSize())
                    else Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.camera_permission_explanation), color = Pal.dim, fontSize = 14.sp)
                        Text(stringResource(R.string.grant_permission), color = Pal.dink, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp)
                            .springClick { ask.launch(Manifest.permission.CAMERA) }
                            .clip(RoundedCornerShape(16.dp)).background(accent).padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    // the film format's frame lines: outside is masked, like a rangefinder
                    // The picture follows how the phone is held while the finder box stays put.
                    val crop = remember(look.format, pictureLandscape, landscape) {
                        val c = Framing.compute(if (pictureLandscape) 4000 else 3000, if (pictureLandscape) 3000 else 4000, look, 4000).crop
                        // The crop is centered, so a quarter turn into the fixed finder swaps the axes.
                        if (pictureLandscape != landscape) floatArrayOf(c[1], c[0], c[3], c[2]) else c
                    }
                    Canvas(Modifier.fillMaxSize()) {
                        val l = crop[0] * size.width; val r = crop[2] * size.width
                        val t = (1 - crop[3]) * size.height; val b = (1 - crop[1]) * size.height
                        val mask = Pal.dark.copy(alpha = 0.78f)
                        if (t > 0f) drawRect(mask, Offset.Zero, Size(size.width, t))
                        if (b < size.height) drawRect(mask, Offset(0f, b), Size(size.width, size.height - b))
                        if (l > 0f) drawRect(mask, Offset(0f, t), Size(l, b - t))
                        if (r < size.width) drawRect(mask, Offset(r, t), Size(size.width - r, b - t))
                        // waist-level ground glass: hairline grid and centre cross, like a TLR focusing screen
                        if (waistLevel) {
                            val grid = Color(0xFFC4A574).copy(alpha = 0.38f)
                            val hair = 0.6.dp.toPx()
                            val fl = l; val fr = r; val ft = t; val fb = b
                            val fw = fr - fl; val fh = fb - ft
                            for (i in 1..2) {
                                val x = fl + fw * i / 3f
                                val y = ft + fh * i / 3f
                                drawLine(grid, Offset(x, ft), Offset(x, fb), hair)
                                drawLine(grid, Offset(fl, y), Offset(fr, y), hair)
                            }
                            val cx = (fl + fr) / 2f; val cy = (ft + fb) / 2f
                            val arm = 14.dp.toPx()
                            drawLine(grid, Offset(cx - arm, cy), Offset(cx + arm, cy), hair * 1.4f)
                            drawLine(grid, Offset(cx, cy - arm), Offset(cx, cy + arm), hair * 1.4f)
                        }
                        // frame not advanced: film sessions wait for ground glass; RAW dims the direct preview here
                        if (clarity.value < 1f) drawRect(Pal.dark.copy(alpha = (if (session?.raw == true) 0.62f else 0.5f) * (1f - clarity.value)))
                        // RAW exposure cannot pass through the film effect, so the direct preview is shaded to match the gesture.
                        if (session?.raw == true && evBias != 0f) drawRect(if (evBias > 0f) Color.White.copy(alpha = (evBias / 4f).coerceIn(0f, 0.45f))
                            else Color.Black.copy(alpha = (-evBias / 4f).coerceIn(0f, 0.55f)))
                        // shutter blades
                        if (blades.value > 0f) {
                            val hgt = size.height / 2 * blades.value
                            drawRect(Color.Black, Offset.Zero, Size(size.width, hgt))
                            drawRect(Color.Black, Offset(0f, size.height - hgt), Size(size.width, hgt))
                        }
                        // focus ring closing in on the tapped point
                        focusAt?.let { c ->
                            if (focusRing.value > 0f) {
                                // white while searching, the roll's colour once sharp, red if the lens gave up
                                val ringColor = when (focusResult) { 1 -> accent; 2 -> Pal.safelight; else -> Pal.text }
                                val rad = (22.dp.toPx()) * (1f + 0.6f * ((focusRing.value - 0.6f).coerceAtLeast(0f) / 0.4f))
                                drawCircle(ringColor.copy(alpha = focusRing.value.coerceAtMost(1f)), radius = rad, center = c,
                                    style = Stroke((if (focusLocked) 2.5f else 1.5f).dp.toPx()))
                                // exposure compensation marker riding next to the ring
                                if (evBias != 0f) {
                                    val x = c.x + rad + 12.dp.toPx()
                                    drawLine(ringColor.copy(alpha = 0.6f), Offset(x, c.y - 26.dp.toPx()), Offset(x, c.y + 26.dp.toPx()), 1.dp.toPx())
                                    drawCircle(ringColor, 4.dp.toPx(), Offset(x, c.y - evBias / 2f * 26.dp.toPx()))
                                }
                            }
                        }
                    }
                    CropCorners(Modifier.fillMaxSize(), busy)
                    // exposure compensation and lock read-outs
                    Column(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalAlignment = Alignment.End) {
                        androidx.compose.animation.AnimatedVisibility(evBias != 0f, enter = fadeIn(), exit = fadeOut()) {
                            Text(signed(((evBias * 10).toInt() / 10.0), 1, " EV"), fontFamily = Fonts.mono, fontSize = 11.sp, color = accent,
                                modifier = Modifier.graphicsLayer { rotationZ = iconTurn }.background(Color(0x99140807)).padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        androidx.compose.animation.AnimatedVisibility(focusLocked, enter = fadeIn(), exit = fadeOut()) {
                            Text(stringResource(R.string.focus_locked), fontSize = 10.sp, color = Pal.dink,
                                modifier = Modifier.padding(top = 4.dp).graphicsLayer { rotationZ = iconTurn }.background(accent, RoundedCornerShape(3.dp)).padding(horizontal = 5.dp, vertical = 1.dp))
                        }
                    }
                    Column(Modifier.align(Alignment.TopStart).padding(10.dp)) {
                        Text(summary(look).uppercase(Locale.ROOT), fontFamily = Fonts.mono, fontSize = 9.sp, color = Pal.text,
                            modifier = Modifier.background(Color(0x99140807)).padding(horizontal = 6.dp, vertical = 2.dp))
                        if (session?.raw == true) Text(stringResource(R.string.raw_preview_notice), fontSize = 10.sp, color = Pal.text,
                            modifier = Modifier.padding(top = 4.dp).background(Color(0x99140807)).padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    // zoom chips live on the metal deck in waist-level mode, not over the ground glass
                    if (!waistLevel) {
                    val stops = lensChoices
                    Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
                        .background(Color(0x80140807), CircleShape).padding(3.dp)) {
                        val nearest = stops.filter { it.second == null }.minByOrNull { kotlin.math.abs(it.first - zoom) }?.first
                        stops.forEach { (z, other) ->
                            val on = other == null && z == nearest
                            val live = on && kotlin.math.abs(zoom - z) > 0.05f
                            val label = if (baseMm != null) "${Math.round(baseMm * (if (live) zoom else z))}" + if (on) "mm" else ""
                                else if (live) "%.1f×".format(zoom)
                                else if (z < 1f) "%.1f".format(z).trimStart('0') else "${z.toInt()}" + if (on) "×" else ""
                            Text(label, fontFamily = Fonts.mono, fontSize = 11.sp,
                                color = if (on) Pal.dink else Pal.text, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 2.dp).springClick {
                                    if (!busy) {
                                        if (other == null) animateZoom(z) else {
                                            zoomJob?.cancel()
                                            zoom = 1f
                                            focusLocked = false
                                            selectedCameraId = other.id
                                        }
                                    }
                                }.graphicsLayer { rotationZ = iconTurn }.clip(CircleShape).background(if (on) accent else Color.Transparent)
                                    .padding(horizontal = 9.dp, vertical = 7.dp))
                        }
                    }
                    }
                }
            }
            Safelight(Modifier.align(Alignment.TopEnd).padding(2.dp))
            if (waistLevel) {
                // subtle focusing-hood vignette around the ground glass
                Canvas(Modifier.matchParentSize()) {
                    drawRect(Brush.radialGradient(
                        0.55f to Color.Transparent,
                        1f to Color(0xCC100C08),
                        center = center,
                        radius = size.minDimension * 0.72f,
                    ))
                }
            }
        }
    }

    val thumbPart: @Composable () -> Unit = {
        // last frame on the lightbox: tap to open it in the darkroom
        val previousDescription = stringResource(R.string.previous_frame)
        Box(Modifier.size(52.dp).graphicsLayer { rotationZ = iconTurn }.clip(RoundedCornerShape(6.dp)).background(Pal.line)
            .semantics { contentDescription = previousDescription }
            .springClick(0.9f) { last?.let { state.openEdit(it.id) } ?: state.say(R.string.no_photos_taken) }) {
            if (last != null) {
                val thumb by produceState(state.app.thumbs.cached(last), last.id, last.uri, last.look) { value = state.app.thumbs.get(last) }
                Crossfade(thumb, label = "last") { t ->
                    if (t != null) Image(t.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
            }
        }
    }
    val shutterPart: @Composable () -> Unit = {
        // shutter release: locked (hollow, dim) until the film is advanced
        val sink by animateFloatAsState(if (busy) 0.72f else 1f, Motion.press, label = "shutter")
        val ready by animateFloatAsState(if (cocked) 1f else 0f, tween(260), label = "ready")
        val shutterDescription = stringResource(if (cocked) R.string.shutter else R.string.shutter_not_advanced)
        Box(Modifier.size(76.dp).semantics { contentDescription = shutterDescription }.springClick(0.9f) { shoot() }
            .border(3.dp, Pal.text.copy(alpha = 0.45f + 0.55f * ready), CircleShape).padding(7.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().graphicsLayer { scaleX = sink; scaleY = sink; alpha = 0.18f + 0.82f * ready }
                .clip(CircleShape).background(if (busy) accent else Pal.text))
        }
    }
    val flipPart: @Composable () -> Unit = {
        val spin = remember { Animatable(0f) }
        val switchDescription = stringResource(R.string.switch_camera)
        Box(Modifier.size(52.dp).semantics { contentDescription = switchDescription }
            .springClick(0.9f) {
                front = !front; selectedCameraId = null; separateLenses = emptyList(); zoomJob?.cancel(); zoom = 1f
                scope.launch { spin.snapTo(0f); spin.animateTo(180f, Motion.settle) }
            }.border(1.dp, Pal.off, CircleShape), contentAlignment = Alignment.Center) {
            // Keep the drawing and rotation anchored to the button's center.
            CameraFlipIcon(Modifier.size(28.dp).graphicsLayer { rotationZ = iconTurn + spin.value }, Pal.text)
        }
    }
    val counter: @Composable () -> Unit = {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.graphicsLayer { rotationZ = iconTurn }) {
            FrameCounter(frame)
            Text("/ 36", fontFamily = Fonts.mono, fontSize = 8.sp, color = Pal.dim)
        }
    }
    val motor: @Composable () -> Unit = {
        // motor drive for those who do not want to wind every frame
        Text(stringResource(if (autoWind) R.string.auto_wind_on else R.string.auto_wind_off),
            color = if (autoWind) accent else Pal.dim, fontSize = 11.sp,
            modifier = Modifier.springClick {
                autoWind = !autoWind
                prefs.edit().putBoolean("autoWind", autoWind).apply()
                if (autoWind && !cocked && !busy) autoStroke++
            }.graphicsLayer { rotationZ = iconTurn }.padding(6.dp))
    }
    // A short sideways window keeps only the lever here; counter and motor move to the other column.
    val transportPart: @Composable (Boolean, Boolean) -> Unit = { vertical, spare ->
        val lever: @Composable () -> Unit = {
            FilmAdvanceLever(cocked, accent, nudge, autoStroke, guidanceEnabled = !busy && !autoWind && activeSheet == Sheet.NONE) { advanceFilm() }
        }
        if (spare) lever()
        else if (vertical) Column(horizontalAlignment = Alignment.CenterHorizontally) { counter(); lever(); motor() }
        else Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            counter(); Spacer(Modifier.width(10.dp)); motor(); Spacer(Modifier.weight(1f)); lever()
        }
    }
    val zoomChips: @Composable () -> Unit = {
        val stops = lensChoices
        Row(Modifier.background(Color(0x66140807), CircleShape).padding(3.dp)) {
            val nearest = stops.filter { it.second == null }.minByOrNull { kotlin.math.abs(it.first - zoom) }?.first
            stops.forEach { (z, other) ->
                val on = other == null && z == nearest
                val live = on && kotlin.math.abs(zoom - z) > 0.05f
                val label = if (baseMm != null) "${Math.round(baseMm * (if (live) zoom else z))}" + if (on) "mm" else ""
                    else if (live) "%.1f×".format(zoom)
                    else if (z < 1f) "%.1f".format(z).trimStart('0') else "${z.toInt()}" + if (on) "×" else ""
                Text(label, fontFamily = Fonts.mono, fontSize = 11.sp,
                    color = if (on) Pal.dink else Pal.text, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.padding(horizontal = 2.dp).springClick {
                        if (!busy) {
                            if (other == null) animateZoom(z) else {
                                zoomJob?.cancel()
                                zoom = 1f
                                focusLocked = false
                                selectedCameraId = other.id
                            }
                        }
                    }.graphicsLayer { rotationZ = iconTurn }.clip(CircleShape).background(if (on) accent else Color.Transparent)
                        .padding(horizontal = 9.dp, vertical = 7.dp))
            }
        }
    }
    val toolsPart: @Composable (Modifier) -> Unit = { modifier ->
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Pal.darkPanel.copy(alpha = 0.96f))) {
            ToolDeck(state, tool, { tool = it }, look, accent, positive, isVideo = false,
                onSet = { _, l -> state.setCamLook(l) }, onApply = { state.setCamLook(it) })
        }
    }

    // ------------------------------------------------------------------ layout
    Box(Modifier.fillMaxSize().background(Pal.dark).statusBarsPadding().navigationBarsPadding()
        .displayCutoutPadding().onGloballyPositioned { origin = it.positionInWindow() }) {
        val tabletop = fold.posture == Posture.TABLETOP && hinge != null && hinge.top > 0f
        val book = fold.posture == Posture.BOOK && hinge != null && hinge.left > 0f
        when {
            tabletop -> Column(Modifier.fillMaxSize().background(Color(0xFF1C1916))) {
                // Waist-level finder: the upright half (behind the rear lenses) is the metal control deck.
                // The flat half the photographer looks down into is the ground glass.
                Column(Modifier.fillMaxWidth().height(with(density) { hinge!!.top.toDp() }).background(
                    Brush.verticalGradient(listOf(Color(0xFF2A2622), Color(0xFF141210))))) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        topItems { Spacer(Modifier.weight(1f)) }
                    }
                    if (toolsOpen) {
                        toolsPart(Modifier.fillMaxWidth().weight(1f).padding(8.dp))
                    } else {
                        Column(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                counter(); Spacer(Modifier.width(16.dp)); motor()
                            }
                            transportPart(false, true)
                            shutterPart()
                            zoomChips()
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                thumbPart(); Spacer(Modifier.width(22.dp)); flipPart()
                            }
                        }
                    }
                }
                Spacer(Modifier.height(with(density) { hinge!!.height.toDp() }))
                Box(Modifier.fillMaxSize().background(Color(0xFF100E0C))) {
                    viewfinderPart(Modifier.fillMaxSize(), true)
                }
            }
            book -> Row(Modifier.fillMaxSize().background(Color(0xFF1C1916))) {
                // Vertical hinge, held sideways: metal controls on the lens half, ground glass on the other.
                Column(Modifier.fillMaxHeight().width(with(density) { hinge!!.left.toDp() }).background(
                    Brush.horizontalGradient(listOf(Color(0xFF2A2622), Color(0xFF141210))))) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        topItems { Spacer(Modifier.weight(1f)) }
                    }
                    if (toolsOpen) {
                        toolsPart(Modifier.fillMaxWidth().weight(1f).padding(8.dp))
                    } else {
                        Column(Modifier.fillMaxWidth().weight(1f).padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
                            transportPart(true, false)
                            zoomChips()
                            Row(verticalAlignment = Alignment.CenterVertically) { thumbPart(); Spacer(Modifier.width(14.dp)); flipPart() }
                            shutterPart()
                        }
                    }
                }
                Spacer(Modifier.width(with(density) { hinge!!.width.toDp() }))
                Box(Modifier.fillMaxSize().background(Color(0xFF100E0C))) {
                    viewfinderPart(Modifier.fillMaxSize(), true)
                }
            }
            landscape -> BoxWithConstraints(Modifier.fillMaxSize()) {
              // The right column needs about 340dp; below that the counter and motor move left.
              val short = maxHeight < 360.dp
              Row(Modifier.fillMaxSize()) {
                // held sideways: settings on the left edge, shutter and lever under the right thumb
                Column(Modifier.fillMaxHeight().padding(vertical = 6.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween) {
                    topItems { }
                    if (short) { counter(); motor() }
                }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    viewfinderPart(Modifier.fillMaxSize(), false)
                    androidx.compose.animation.AnimatedVisibility(toolsOpen, Modifier.align(Alignment.CenterEnd),
                        enter = slideInHorizontally(Motion.glideOffset) { it } + fadeIn(), exit = slideOutHorizontally(tween(200)) { it } + fadeOut()) {
                        toolsPart(Modifier.width(340.dp).fillMaxHeight().padding(6.dp))
                    }
                }
                Column(Modifier.fillMaxHeight().padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween) {
                    flipPart(); transportPart(true, short); shutterPart(); thumbPart()
                }
              }
            }
            else -> Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().dealIn(0, fromY = -40f).padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { topItems { Spacer(Modifier.weight(1f)) } }
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    viewfinderPart(Modifier.fillMaxSize(), false)
                    androidx.compose.animation.AnimatedVisibility(toolsOpen, Modifier.align(Alignment.BottomCenter),
                        enter = slideInVertically(Motion.glideOffset) { it } + fadeIn(), exit = slideOutVertically(tween(200)) { it } + fadeOut()) {
                        toolsPart(Modifier.fillMaxWidth().height(300.dp).padding(6.dp))
                    }
                }
                transportPart(false, false)
                Row(Modifier.fillMaxWidth().dealIn(1, fromY = 60f).padding(horizontal = 30.dp).padding(bottom = 14.dp, top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    thumbPart(); shutterPart(); flipPart()
                }
            }
        }
    }
}

/**
 * Ask the camera for what a raw developer needs and a JPEG pipeline does itself:
 * the lens shading map (DngCreator then embeds it as gain maps, so vignetting and colour
 * shading can be corrected) and hot pixel correction on the sensor data.
 */
@androidx.annotation.OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
private fun requestRawMetadata(builder: ImageCapture.Builder, results: android.hardware.camera2.CameraCaptureSession.CaptureCallback) {
    runCatching {
        androidx.camera.camera2.interop.Camera2Interop.Extender(builder)
            .setCaptureRequestOption(android.hardware.camera2.CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE,
                android.hardware.camera2.CameraMetadata.STATISTICS_LENS_SHADING_MAP_MODE_ON)
            .setCaptureRequestOption(android.hardware.camera2.CaptureRequest.HOT_PIXEL_MODE,
                android.hardware.camera2.CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY)
            // the capture result of every frame: a raw frame becomes a DNG with its own
            .setSessionCaptureCallback(results)
    }
}

@androidx.annotation.OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
private fun cameraCharacteristics(context: android.content.Context, camera: Camera): android.hardware.camera2.CameraCharacteristics? = runCatching {
    val id = androidx.camera.camera2.interop.Camera2CameraInfo.from(camera.cameraInfo).cameraId
    context.getSystemService(android.hardware.camera2.CameraManager::class.java).getCameraCharacteristics(id)
}.getOrNull()

/** Base 35mm-equivalent focal length (zoom 1.0) and the zoom ratios of the phone's physical lenses. */
private class LensInfo(val id: String, val baseMm: Float, val stops: List<Float>)
private class SeparateLens(val id: String, val baseMm: Float, val selector: CameraSelector)

private fun equivalentFocalLengths(c: android.hardware.camera2.CameraCharacteristics): List<Float> {
    val size = c.get(android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return emptyList()
    val diagonal = kotlin.math.hypot(size.width, size.height)
    if (!diagonal.isFinite() || diagonal <= 0f) return emptyList()
    val focalLengths = c.get(android.hardware.camera2.CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
        ?: return emptyList()
    return focalLengths.map { it * 43.27f / diagonal }.filter { it.isFinite() && it > 0f }
}

@androidx.annotation.OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
private fun discoverSeparateLenses(provider: ProcessCameraProvider, facing: CameraSelector): List<SeparateLens> =
    facing.filter(provider.availableCameraInfos).mapNotNull { cameraInfo ->
        runCatching {
            val info = androidx.camera.camera2.interop.Camera2CameraInfo.from(cameraInfo)
            val chars = info.getCameraCharacteristicsMap()[info.cameraId] ?: return@runCatching null
            val base = equivalentFocalLengths(chars).firstOrNull() ?: return@runCatching null
            SeparateLens(info.cameraId, base, cameraInfo.cameraSelector)
        }.getOrNull()
    }

@androidx.annotation.OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
private fun readLens(context: android.content.Context, camera: Camera): LensInfo? = runCatching {
    val info = androidx.camera.camera2.interop.Camera2CameraInfo.from(camera.cameraInfo)
    val manager = context.getSystemService(android.hardware.camera2.CameraManager::class.java)
    val logical = info.getCameraCharacteristicsMap()[info.cameraId]
        ?: manager.getCameraCharacteristics(info.cameraId)
    val focalLengths = equivalentFocalLengths(logical)
    val base = focalLengths.firstOrNull() ?: return@runCatching null
    // One inaccessible physical ID must not discard the other lenses.
    val physical = if (android.os.Build.VERSION.SDK_INT >= 28) logical.physicalCameraIds.flatMap { id ->
        runCatching { equivalentFocalLengths(manager.getCameraCharacteristics(id)) }.getOrDefault(emptyList())
    } else emptyList()
    LensInfo(info.cameraId, base, (focalLengths + physical).map { it / base })
}.getOrNull()
